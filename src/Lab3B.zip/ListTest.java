
public class ListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoubleList da = new DoubleList();//creates the object for DoubleArray()
		PointList p3d = new PointList();// creates object for PointArray()
		da.createList();// constructor print calls
		da.printList();
		p3d.createList();
		p3d.printList();

	}

}
